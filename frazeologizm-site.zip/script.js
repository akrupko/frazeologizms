// Phraseological Units Training Game

class PhraseologyTrainer {
    constructor() {
        this.phrases = [];
        this.currentQuestion = null;
        this.correctAnswers = 0;
        this.totalQuestions = 0;
        this.usedPhrases = new Set();
        
        this.init();
    }
    
    async init() {
        await this.loadPhrases();
        this.setupEventListeners();
        this.startNewQuestion();
    }
    
    async loadPhrases() {
        try {
            console.log('Loading table_phrases.json...');
            
            // Try to detect if we're running from file:// protocol
            const isFileProtocol = window.location.protocol === 'file:';
            if (isFileProtocol) {
                console.warn('Running from file:// protocol - some browsers may have CORS restrictions');
            }
            
            const response = await fetch('table_phrases.json');
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Get current category from URL or window variable
            const currentCategory = window.CURRENT_CATEGORY || this.getCategoryFromURL();
            
            // Filter phrases based on category
            let allPhrases = data.phrases || [];
            
            if (currentCategory && currentCategory !== 'general') {
                // Filter by specific category
                this.phrases = allPhrases.filter(phrase => 
                    phrase.category === currentCategory &&
                    phrase.meanings && 
                    phrase.meanings.length > 0 && 
                    phrase.meanings[0] !== "Значение требует уточнения" &&
                    phrase.meanings[0].trim().length > 10
                );
                
                // Set category name for display
                const categoryInfo = data.categories && data.categories[currentCategory];
                if (categoryInfo) {
                    window.CATEGORY_NAME = categoryInfo.name;
                }
            } else {
                // Use all phrases for general category
                this.phrases = allPhrases.filter(phrase => {
                    return phrase.meanings && 
                           phrase.meanings.length > 0 && 
                           phrase.meanings[0] !== "Значение требует уточнения" &&
                           phrase.meanings[0].trim().length > 10;
                });
                window.CATEGORY_NAME = 'Все категории';
            }
            
            console.log(`Loaded ${this.phrases.length} valid phrases for ${window.CATEGORY_NAME}`);
            
            if (this.phrases.length === 0) {
                throw new Error('No valid phrases found for this category');
            }
            
            // Hide loading, show quiz
            document.getElementById('loading').style.display = 'none';
            document.getElementById('quiz-content').style.display = 'block';
            
        } catch (error) {
            console.error('Error loading phrases:', error);
            
            // Provide more specific error information
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                console.error('CORS or network error - this might be due to browser security restrictions when running from file:// protocol');
            }
            
            this.showError(error);
        }
    }
    
    getCategoryFromURL() {
        const path = window.location.pathname;
        const filename = path.split('/').pop() || 'index.html';
        
        // Map filenames to categories
        const urlCategoryMap = {
            'index.html': 'general',
            // Old filenames (for backward compatibility)
            'animals.html': 'animals',
            'body-parts.html': 'body_parts',
            'emotions.html': 'emotions_feelings',
            'religion.html': 'religion_mythology',
            'work.html': 'work_labor',
            'family.html': 'family_relationships',
            'mind.html': 'mind_intelligence',
            'speech.html': 'speech_communication',
            'money.html': 'money_wealth',
            'time.html': 'time_age',
            'food.html': 'food_drink',
            'house.html': 'house_home',
            // New frazeologizmy_ prefixed filenames
            'frazeologizmy_animals.html': 'animals',
            'frazeologizmy_body-parts.html': 'body_parts',
            'frazeologizmy_emotions.html': 'emotions_feelings',
            'frazeologizmy_religion.html': 'religion_mythology',
            'frazeologizmy_work.html': 'work_labor',
            'frazeologizmy_family.html': 'family_relationships',
            'frazeologizmy_mind.html': 'mind_intelligence',
            'frazeologizmy_speech.html': 'speech_communication',
            'frazeologizmy_money.html': 'money_wealth',
            'frazeologizmy_time.html': 'time_age',
            'frazeologizmy_food.html': 'food_drink',
            'frazeologizmy_house.html': 'house_home',
            'frazeologizmy_appearance_beauty.html': 'appearance_beauty',
            'frazeologizmy_clothes_appearance.html': 'clothes_appearance',
            'frazeologizmy_games_entertainment.html': 'games_entertainment',
            'frazeologizmy_luck_fortune.html': 'luck_fortune',
            'frazeologizmy_quantity_measure.html': 'quantity_measure',
            'frazeologizmy_transport_travel.html': 'transport_travel',
            'frazeologizmy_war_conflict.html': 'war_conflict',
            'frazeologizmy_weather_nature.html': 'weather_nature'
        };
        
        return urlCategoryMap[filename] || 'general';
    }
    
    setupEventListeners() {
        document.getElementById('next-button').addEventListener('click', () => {
            this.startNewQuestion();
        });
        
        document.getElementById('restart-button').addEventListener('click', () => {
            this.restart();
        });
        
        document.getElementById('show-etymology').addEventListener('click', () => {
            this.toggleEtymology();
        });
    }
    
    startNewQuestion() {
        // Hide feedback and etymology
        document.getElementById('feedback').style.display = 'none';
        document.getElementById('etymology-info').style.display = 'none';
        document.getElementById('show-etymology').style.display = 'none';
        
        // Get a random phrase that hasn't been used recently
        const availablePhrases = this.phrases.filter(p => !this.usedPhrases.has(p.phrase));
        
        // If we've used all phrases, reset the used set but keep some recent ones
        if (availablePhrases.length === 0) {
            this.usedPhrases.clear();
            console.log('Reset used phrases - starting new cycle');
        }
        
        const randomIndex = Math.floor(Math.random() * (availablePhrases.length || this.phrases.length));
        const selectedPhrase = availablePhrases.length > 0 ? availablePhrases[randomIndex] : this.phrases[randomIndex];
        
        this.currentQuestion = selectedPhrase;
        this.usedPhrases.add(selectedPhrase.phrase);
        
        // Keep usedPhrases manageable
        if (this.usedPhrases.size > Math.floor(this.phrases.length * 0.7)) {
            const phrasesToKeep = Array.from(this.usedPhrases).slice(-Math.floor(this.phrases.length * 0.3));
            this.usedPhrases = new Set(phrasesToKeep);
        }
        
        this.displayQuestion();
        this.generateAnswerOptions();
    }
    
    displayQuestion() {
        document.getElementById('phrase').textContent = this.currentQuestion.phrase;
    }
    
    generateAnswerOptions() {
        const correctMeaning = this.getRandomMeaning(this.currentQuestion);
        const incorrectMeanings = this.getRandomIncorrectMeanings(correctMeaning, 2);
        
        // Combine and shuffle
        const allOptions = [correctMeaning, ...incorrectMeanings];
        this.shuffleArray(allOptions);
        
        // Store correct answer for checking
        this.correctAnswer = correctMeaning;
        
        this.displayAnswerOptions(allOptions);
    }
    
    getRandomMeaning(phrase) {
        const meanings = phrase.meanings.filter(m => 
            m && m.trim().length > 10 && m !== "Значение требует уточнения"
        );
        
        if (meanings.length === 0) {
            return "Значение недоступно";
        }
        
        return meanings[Math.floor(Math.random() * meanings.length)];
    }
    
    getRandomIncorrectMeanings(correctMeaning, count) {
        const incorrectMeanings = [];
        const availablePhrases = this.phrases.filter(p => p !== this.currentQuestion);
        
        while (incorrectMeanings.length < count && availablePhrases.length > 0) {
            const randomPhrase = availablePhrases[Math.floor(Math.random() * availablePhrases.length)];
            const meaning = this.getRandomMeaning(randomPhrase);
            
            // Avoid duplicates and make sure it's different from correct answer
            if (meaning !== correctMeaning && 
                !incorrectMeanings.includes(meaning) &&
                meaning !== "Значение недоступно") {
                incorrectMeanings.push(meaning);
            }
            
            // Remove used phrase to avoid infinite loop
            const index = availablePhrases.indexOf(randomPhrase);
            availablePhrases.splice(index, 1);
        }
        
        // If we couldn't find enough different meanings, add some generic ones
        while (incorrectMeanings.length < count) {
            const genericMeanings = [
                "выражение радости или удовлетворения",
                "обозначение быстрого движения или действия", 
                "описание сложной или запутанной ситуации",
                "характеристика ненадежного человека",
                "обозначение большого количества чего-либо"
            ];
            
            const generic = genericMeanings[Math.floor(Math.random() * genericMeanings.length)];
            if (!incorrectMeanings.includes(generic) && generic !== correctMeaning) {
                incorrectMeanings.push(generic);
            }
        }
        
        return incorrectMeanings;
    }
    
    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }
    
    displayAnswerOptions(options) {
        const container = document.getElementById('answer-options');
        container.innerHTML = '';
        
        options.forEach((option, index) => {
            const button = document.createElement('button');
            button.className = 'answer-button';
            button.textContent = option;
            button.addEventListener('click', () => this.handleAnswer(option, button));
            container.appendChild(button);
        });
    }
    
    handleAnswer(selectedMeaning, buttonElement) {
        const isCorrect = selectedMeaning === this.correctAnswer;
        
        // Disable all buttons
        const allButtons = document.querySelectorAll('.answer-button');
        allButtons.forEach(btn => {
            btn.classList.add('disabled');
            btn.style.pointerEvents = 'none';
            
            // Mark correct/incorrect
            if (btn.textContent === this.correctAnswer) {
                btn.classList.add('correct');
            } else if (btn === buttonElement && !isCorrect) {
                btn.classList.add('incorrect');
            }
        });
        
        this.totalQuestions++;
        
        if (isCorrect) {
            this.correctAnswers++;
            this.showFeedback(true, "Правильно! 🎉", "Отличная работа!");
        } else {
            this.showFeedback(false, "Неправильно 😔", `Правильный ответ: ${this.correctAnswer}`);
        }
        
        this.updateStats();
        this.showControls();
    }
    
    showFeedback(isCorrect, title, message) {
        const feedback = document.getElementById('feedback');
        const feedbackMessage = document.getElementById('feedback-message');
        const correctAnswer = document.getElementById('correct-answer');
        
        feedback.className = `feedback ${isCorrect ? 'success' : 'error'}`;
        feedbackMessage.innerHTML = `<span class="emoji">${isCorrect ? '✅' : '❌'}</span>${title}`;
        
        // Add etymology if available (for both correct and incorrect answers)
        if (this.currentQuestion.etymology && this.currentQuestion.etymology.trim()) {
            correctAnswer.innerHTML = `${message}<br><br><strong>📖 Происхождение:</strong> ${this.currentQuestion.etymology}`;
        } else {
            correctAnswer.textContent = message;
        }
        
        feedback.style.display = 'block';
    }
    
    showControls() {
        document.getElementById('restart-button').style.display = 'inline-block';
        
        // Show etymology button if etymology is available
        if (this.currentQuestion.etymology && this.currentQuestion.etymology.trim()) {
            document.getElementById('show-etymology').style.display = 'inline-block';
        }
    }
    
    toggleEtymology() {
        const etymologyInfo = document.getElementById('etymology-info');
        const etymologyText = document.getElementById('etymology-text');
        
        if (etymologyInfo.style.display === 'none' || !etymologyInfo.style.display) {
            etymologyText.textContent = this.currentQuestion.etymology || 'Информация о происхождении недоступна';
            etymologyInfo.style.display = 'block';
        } else {
            etymologyInfo.style.display = 'none';
        }
    }
    
    updateStats() {
        document.getElementById('correct-count').textContent = this.correctAnswers;
        document.getElementById('total-count').textContent = `${this.totalQuestions} / ${this.phrases.length}`;
        
        const accuracy = this.totalQuestions > 0 ? 
            Math.round((this.correctAnswers / this.totalQuestions) * 100) : 0;
        document.getElementById('accuracy').textContent = `${accuracy}%`;
    }
    
    restart() {
        this.correctAnswers = 0;
        this.totalQuestions = 0;
        this.usedPhrases.clear();
        this.updateStats();
        this.startNewQuestion();
    }
    
    showError(error) {
        console.error('Showing error to user:', error);
        
        document.getElementById('loading').style.display = 'none';
        document.getElementById('quiz-content').style.display = 'none';
        
        const errorMessageDiv = document.getElementById('error-message');
        const isFileProtocol = window.location.protocol === 'file:';
        
        // Update error message based on the specific error and browser
        let errorContent = `
            <h3>❌ Ошибка загрузки</h3>
            <p>Не удалось загрузить базу фразеологизмов.</p>
        `;
        
        // Add specific troubleshooting for file:// protocol issues
        if (isFileProtocol) {
            errorContent += `
                <div style="background: #fef3c7; border: 1px solid #f59e0b; padding: 15px; border-radius: 8px; margin: 15px 0; text-align: left;">
                    <h4 style="color: #92400e; margin-top: 0;">📝 Рекомендации для Google Chrome:</h4>
                    <p style="color: #92400e; margin-bottom: 8px;">Для корректной работы в Chrome рекомендуется:</p>
                    <ul style="color: #92400e; text-align: left; padding-left: 20px;">
                        <li>Использовать локальный веб-сервер</li>
                        <li>Или открыть сайт в Microsoft Edge</li>
                        <li>Или запустить Chrome с параметром --allow-file-access-from-files</li>
                    </ul>
                </div>
            `;
        }
        
        // Add error details if available
        if (error && error.message) {
            errorContent += `
                <details style="margin-top: 15px; text-align: left;">
                    <summary style="cursor: pointer; color: #991b1b;">Подробности ошибки</summary>
                    <p style="background: #fef2f2; padding: 10px; border-radius: 4px; margin-top: 8px; font-family: monospace; font-size: 0.9em; color: #7f1d1d;">
                        ${error.message}
                    </p>
                </details>
            `;
        }
        
        errorContent += `
            <button onclick="location.reload()" class="retry-button">Попробовать снова</button>
        `;
        
        errorMessageDiv.innerHTML = errorContent;
        errorMessageDiv.style.display = 'block';
    }
}

// Initialize the trainer when the page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing trainer...');
    window.trainer = new PhraseologyTrainer();
});

// Add some visual feedback for button interactions
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('answer-button') || 
        e.target.classList.contains('next-button') ||
        e.target.classList.contains('control-button')) {
        
        // Add click animation
        e.target.style.transform = 'scale(0.95)';
        setTimeout(() => {
            e.target.style.transform = '';
        }, 150);
    }
});

// Add keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key >= '1' && e.key <= '3') {
        const buttons = document.querySelectorAll('.answer-button:not(.disabled)');
        const index = parseInt(e.key) - 1;
        if (buttons[index]) {
            buttons[index].click();
        }
    } else if (e.key === 'Enter' || e.key === ' ') {
        const nextButton = document.getElementById('next-button');
        if (nextButton.offsetParent !== null) { // Check if visible
            nextButton.click();
        }
    }
});